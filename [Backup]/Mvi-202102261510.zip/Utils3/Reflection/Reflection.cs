﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharlyBeck.Utils3.Reflection
{
   using System.Reflection;

   //public static class CReflectionExtensions
   //{
   //   public static T[] GetEnumValues<T>(this Type aType)
   //      => (from aField in aType.GetFields()
   //          where (aField.Attributes & FieldAttributes.SpecialName) == 0
   //          select aField.GetValue(default)).Cast<T>().ToArray();
   //}
}
