﻿using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MviMono.GameCore.Models
{

    public abstract class CModel
    {

    }

    //public sealed class CBumperModel : CModel
    //{
    //    internal CBumperModel()
    //    {
    //    }

    //    private static void Normalize(double[] v)
    //    {
    //        double len = Math.Sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    //        v[0] /= len;
    //        v[1] /= len;
    //        v[2] /= len;
    //    }

    //    private static double Dot(double[] x, double[] y)
    //    {
    //        double d = x[0] * y[0] + x[1] * y[1] + x[2] * y[2];
    //        return d < 0 ? -d : 0;
    //    }


    //    private VertexBuffer VertexBuffer;
    //}
}
