﻿using CharlyBeck.Mvi.Cube;
using CharlyBeck.Mvi.Facade;
using CharlyBeck.Utils3.Exceptions;
using CharlyBeck.Utils3.LazyLoad;
using CharlyBeck.Utils3.ServiceLocator;
using CharlyBeck.Mvi.World;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using CharlyBeck.Utils3.Enumerables;

namespace CharlyBeck.Mvi.Cube
{
    partial class CTileDataLoadProxy
    {
        #region TileBuilder
        private CTileBuilder TileBuilderM;
        internal CTileBuilder TileBuilder => CLazyLoad.Get(ref this.TileBuilderM, () => new CTileBuilder(this));
        internal override CLoadedTileData NewLoaded()
              => this.TileBuilder.NewLoadedTileData(this);
        #endregion
    }
}
namespace CharlyBeck.Mvi.World
{

    internal abstract class CWorldTileDescriptor : CTileDescriptor
    {
        #region ctor
        internal CWorldTileDescriptor(CTileBuilder aTileBuilder) : base(aTileBuilder)
        {
        }
        #endregion

    }

    internal abstract class CQuadrantTileDescriptor : CWorldTileDescriptor
    {
        #region ctor
        internal CQuadrantTileDescriptor(CTileBuilder aTileBuilder) : base(aTileBuilder)
        {
            this.QuadrantSpriteData = new CQuadrantSpriteData(aTileBuilder, this);
        }
        #endregion

        internal readonly CQuadrantSpriteData QuadrantSpriteData;

        internal override void Draw()
        {
            base.Draw();
            this.QuadrantSpriteData.Draw();
        }
    }


    public sealed class CBeyoundSpaceSpriteData : CSpriteData
    {
        internal CBeyoundSpaceSpriteData(CTileBuilder aTileBuilder, CTileDescriptor aTileDescriptor) : base(aTileBuilder, aTileDescriptor)
        {
            this.Init();
        }
        internal override ISprite NewSprite()
            => this.NewSprite(this);
    }

    internal sealed class CBeyoundSpaceTileDescriptor : CQuadrantTileDescriptor
    {
        #region ctor
        internal CBeyoundSpaceTileDescriptor(CTileBuilder aTileBuilder) : base(aTileBuilder)
        {
            this.BeyoundSpaceSprite = new CBeyoundSpaceSpriteData(aTileBuilder, this);
        }
        #endregion
        private readonly CBeyoundSpaceSpriteData BeyoundSpaceSprite;

    }

    internal sealed class CInSpaceTileDescriptor : CQuadrantTileDescriptor
    {
        #region ctor
        internal CInSpaceTileDescriptor(CTileBuilder aTileBuilder) : base(aTileBuilder)
        {
            var aWorldGenerator = aTileBuilder.WorldGenerator;
            var aWorld = aTileBuilder.World;
            var aBumperCount = aWorldGenerator.NextInteger(aWorld.TileBumperCountMin, aWorld.TileBumperCountMax);
            var aBumpers = new CBumperSpriteData[aBumperCount];
            for (var aIdx = 0; aIdx < aBumperCount; ++aIdx)
                aBumpers[aIdx] = new CBumperSpriteData(aTileBuilder, this);
            this.Bumpers = aBumpers;
        }
        internal override void Draw()
        {
            base.Draw();

            foreach (var aBumper in this.Bumpers)
                aBumper.Draw();
        }
        internal CBumperSpriteData[] Bumpers;
        #endregion
    }

    internal sealed class CWorldGenerator : CRandomGenerator
    {
        #region ctor
        internal CWorldGenerator(CBase aParent) : base(aParent)
        {
            this.Init();
        }
        public override T Throw<T>(Exception aException)
           => aException.Throw<T>();


        #endregion
    }

    public abstract class CSpriteData
    {
        internal CSpriteData(CTileBuilder aTileBuilder, CTileDescriptor aTileDescriptor)
        {
            this.WorldGenerator = aTileBuilder.WorldGenerator;
            this.Facade = aTileBuilder.Facade;
            this.Changes = new BitArray(this.ChangesCount);
            this.AbsoluteCubeCoordinates = aTileBuilder.Tile.AbsoluteCubeCoordinates;
            aTileDescriptor.SpriteDatas.Add(this);
        }
        internal virtual void Init()
        {
            this.Sprite = this.NewSprite();
            this.Update();
        }

        public readonly CCubePos AbsoluteCubeCoordinates;
        internal CWorldPos WorldPos => this.World.GetWorldPos(this.AbsoluteCubeCoordinates);


        internal readonly CFacade Facade;
        internal CWorld World => this.Facade.World;
        internal readonly CWorldGenerator WorldGenerator;
        internal abstract ISprite NewSprite();
        internal ISprite<TData> NewSprite<TData>(TData aData)
            => this.Facade.NewSprite<TData>(aData);
        internal virtual int ChangesCount => 0;
        internal ISprite Sprite { get; private set; }
        internal readonly BitArray Changes;
        internal void Update()
        {
            if (this.Sprite is object)
            {
                this.Sprite.Update(this.Changes);
            }
            this.Changes.SetAll(false);
        }

        internal virtual bool Visible => true;
        internal void Draw()
        {
            if (this.Visible)
            {
                this.Sprite.Draw();
            }
        }

        internal void Unload()
        {
            if (this.Sprite is object)
            {
                this.Sprite.Unload();
            }
        }

        public bool IsNearest;

        internal virtual void RefreshFrameInfo()
        {
            this.IsNearest = object.ReferenceEquals(this.World.WorldFrameInfo.SpriteDistances.First().Item1, this);
        }
    }

    public static class CExtensions
    {
        public static IEnumerable<CWorldPos> PolyPointsToLines(this IEnumerable<CWorldPos> aSquare)
        {
            var aFirst = aSquare.First();
            var aPrevious = aSquare.First();
            foreach (var aPoint in aSquare.Skip(1))
            {
                yield return aPrevious;
                yield return aPoint;
                aPrevious = aPoint;
            }
            yield return aPrevious;
            yield return aFirst;
        }

    }

    public sealed class CQuadrantSpriteData : CSpriteData
    {
        internal CQuadrantSpriteData(CTileBuilder aTileBuilder, CTileDescriptor aTileDescriptor) : base(aTileBuilder, aTileDescriptor)
        {
            var aTile = aTileBuilder.Tile;
            var aWorld = aTileBuilder.World;
            var aSize2 = aWorld.TileEdgeLen;

            this.Coordinates2 = aWorld.GetWorldPos(aTile);
            this.Size2 = aSize2;

            this.FrontBottomLeft2 = new CWorldPos(this.Coordinates2.x, this.Coordinates2.y, this.Coordinates2.z);
            this.FrontTopLeft2 = new CWorldPos(this.Coordinates2.x, this.Coordinates2.y + aSize2, this.Coordinates2.z);
            this.FrontTopRight2 = new CWorldPos(this.Coordinates2.x + aSize2, this.Coordinates2.y + aSize2, this.Coordinates2.z);
            this.FrontBottomRight2 = new CWorldPos(this.Coordinates2.x + aSize2, this.Coordinates2.y, this.Coordinates2.z);

            this.BackBottomLeft2 = new CWorldPos(this.Coordinates2.x, this.Coordinates2.y, this.Coordinates2.z + aSize2);
            this.BackTopLeft2 = new CWorldPos(this.Coordinates2.x, this.Coordinates2.y + aSize2, this.Coordinates2.z + aSize2);
            this.BackTopRight2 = new CWorldPos(this.Coordinates2.x + aSize2, this.Coordinates2.y + aSize2, this.Coordinates2.z + aSize2);
            this.BackBottomRight2 = new CWorldPos(this.Coordinates2.x + aSize2, this.Coordinates2.y, this.Coordinates2.z + aSize2);

            this.Init();
        }
        internal override ISprite NewSprite()
           => this.NewSprite<CQuadrantSpriteData>(this);
        internal override int ChangesCount => 0;

        public readonly CWorldPos Coordinates2;
        public readonly double Size2;

        public readonly CWorldPos FrontBottomLeft2;
        public readonly CWorldPos FrontTopLeft2;
        public readonly CWorldPos FrontTopRight2;
        public readonly CWorldPos FrontBottomRight2;
        public readonly CWorldPos BackBottomLeft2;
        public readonly CWorldPos BackTopLeft2;
        public readonly CWorldPos BackTopRight2;
        public readonly CWorldPos BackBottomRight2;

        internal override bool Visible => this.World.QuadrantGridLines;
        public IEnumerable<CWorldPos> FrontSquare2
        {
            get
            {
                yield return this.FrontBottomLeft2;
                yield return this.FrontTopLeft2;
                yield return this.FrontTopRight2;
                yield return this.FrontBottomRight2;
            }
        }


        public IEnumerable<CWorldPos> BackSquare2
        {
            get
            {
                yield return this.BackBottomLeft2;
                yield return this.BackTopLeft2;
                yield return this.BackTopRight2;
                yield return this.BackBottomRight2;
            }
        }

        public IEnumerable<CWorldPos> TopSquare2
        {
            get
            {
                yield return this.FrontTopLeft2;
                yield return this.BackTopLeft2;
                yield return this.BackTopRight2;
                yield return this.FrontTopRight2;
            }
        }

        public IEnumerable<CWorldPos> BottomSquare2
        {
            get
            {
                yield return this.FrontBottomLeft2;
                yield return this.BackBottomLeft2;
                yield return this.BackBottomRight2;
                yield return this.FrontBottomRight2;
            }
        }

        public IEnumerable<CWorldPos> LeftSquare2
        {
            get
            {
                yield return this.FrontBottomLeft2;
                yield return this.FrontTopLeft2;
                yield return this.BackTopLeft2;
                yield return this.BackBottomLeft2;
            }
        }

        public IEnumerable<CWorldPos> RightSquare2
        {
            get
            {
                yield return this.FrontBottomRight2;
                yield return this.FrontTopRight2;
                yield return this.BackTopRight2;
                yield return this.BackBottomRight2;
            }
        }



        public IEnumerable<CWorldPos> Lines2
        {
            get
            {
                //yield return this.FrontBottomLeft;
                //yield return this.FrontBottomRight;
                //              yield return this.FrontBottomLeft;
                //                yield return this.FrontTopLeft;#

                foreach (var aPoint in this.FrontSquare2.PolyPointsToLines()) //.Subset(2,4))
                    yield return aPoint;
                foreach (var aPoint in this.BackSquare2.PolyPointsToLines())
                    yield return aPoint;
                foreach (var aPoint in this.LeftSquare2.PolyPointsToLines())
                    yield return aPoint;
                foreach (var aPoint in this.TopSquare2.PolyPointsToLines())
                    yield return aPoint;
                foreach (var aPoint in this.RightSquare2.PolyPointsToLines())
                    yield return aPoint;
                foreach (var aPoint in this.BottomSquare2.PolyPointsToLines())
                    yield return aPoint;
            }
        }
    }

    internal sealed class CEnums<TEnum>
    {
        internal CEnums()
        {
            this.Fields = typeof(TEnum).GetEnumValues().OfType<TEnum>().ToArray();
        }
        internal readonly TEnum[] Fields;

    }

    public sealed class CBumperSpriteData : CSpriteData
    {
        private static readonly CEnums<CAccelerateEnum> AllAccelerateEnums = new CEnums<CAccelerateEnum>();

        internal CBumperSpriteData(CTileBuilder aTileBuilder, CTileDescriptor aTileDescriptor) : base(aTileBuilder, aTileDescriptor)
        {
            var aWorldGenerator = aTileBuilder.WorldGenerator;
            var aWorld = aTileBuilder.World;
            var aTile = aTileBuilder.Tile;
            var aTileAbsoluteCubeCoordinates = aTile.AbsoluteCubeCoordinates;
            this.Coordinates2 = aWorld.GetWorldPos(aTileAbsoluteCubeCoordinates).Add(aWorldGenerator.NextDouble(aWorld.TileEdgeLens));
            this.Radius = aWorldGenerator.NextDouble(aWorld.BumperRadiusMax);
            this.Color = aWorldGenerator.NextWorldPos();
            this.AccelerateEnums = aWorldGenerator.NextItems<CAccelerateEnum>(AllAccelerateEnums.Fields);
            this.GravityIsEnabled = this.AccelerateEnums.Contains(CAccelerateEnum.Gravity);
            this.GravityRadius = aWorldGenerator.NextDouble(aWorld.BumperGravityRadiusMax);
            this.GravityStrength = aWorldGenerator.NextDouble(aWorld.BumperGravityStrengthMax);
            this.GravityRepulsive = aWorldGenerator.NextBoolean();
            this.AccelerateIsEnabled = this.AccelerateEnums.Contains(CAccelerateEnum.Accelerate);
            this.AccelerateHasVector = aWorldGenerator.NextBoolean();
            this.AccelerateVector = aWorldGenerator.NextWorldPos();
            this.AccelerateStrength = aWorldGenerator.NextDouble(1.0d);
            this.AccelerateIsRepulsive = aWorldGenerator.NextBoolean();

            this.Init();
        }

        internal override ISprite NewSprite()
           => this.Facade.NewSprite(this);
        internal override int ChangesCount => (int)CChangeEnum._Count;

        public readonly CWorldPos Coordinates2;
        public readonly double Radius;
        public readonly CWorldPos Color;
        internal readonly CAccelerateEnum[] AccelerateEnums;
        public readonly bool GravityIsEnabled;
        public readonly double GravityRadius;
        public readonly double GravityStrength;
        public readonly bool GravityRepulsive;
        public readonly bool AccelerateIsEnabled;
        public readonly bool AccelerateHasVector;
        public readonly CWorldPos AccelerateVector;
        public readonly double AccelerateStrength;
        public readonly bool AccelerateIsRepulsive;


        internal enum CChangeEnum
        {
            _Count
        }


        internal enum CAccelerateEnum
        {
            Gravity,
            Accelerate
        }
    }

    internal sealed class CTileBuilder : CBase
    {
        #region ctor
        internal CTileBuilder(CBase aParent) : base(aParent)
        {
            this.WorldGenerator = new CWorldGenerator(this);
            this.Facade = this.ServiceContainer.GetService<CFacade>();
            this.Init();
        }
        public override T Throw<T>(Exception aException)
           => aException.Throw<T>();
        #endregion
        #region Tile
        private CTile TileM;
        internal CTile Tile => CLazyLoad.Get(ref this.TileM, () => this.ServiceContainer.GetService<CTile>());
        #endregion
        #region TileDescriptor
        internal CTileDescriptor NewTileDescriptor()
        {

            var aWorld = this.World;
            var aTile = this.Tile;
            //System.Diagnostics.Debug.Print("NewTileDescriptor: " + aTile.AbsoluteCubeCoordinates.ToString());
            var aIsBeyound = aWorld.IsBeyound(aTile);
            var aWorldGenerator = this.WorldGenerator;
            aWorldGenerator.Reset(aTile);
            if (aIsBeyound)
            {
                System.Diagnostics.Debug.Print("NewTileDescriptor: CBeyoundSpaceTileDescriptor" + aTile.AbsoluteCubeCoordinates.ToString());
                var aTileDescriptor = new CBeyoundSpaceTileDescriptor(this);
                return aTileDescriptor;
            }
            else
            {
                var aTileDescriptor = new CInSpaceTileDescriptor(this);
                return aTileDescriptor;
            }
        }

        internal CLoadedTileData NewLoadedTileData(CTileDataLoadProxy aTileDataLoadProxy)
           => CLoadedTileData.New(this, this.NewTileDescriptor());
        #endregion
        #region World
        private CWorld WorldM;
        internal CWorld World => CLazyLoad.Get(ref this.WorldM, () => this.ServiceContainer.GetService<CWorld>());
        #endregion
        #region WorldGenerator
        internal readonly CWorldGenerator WorldGenerator;
        #endregion
        #region Facade
        internal CFacade Facade { get; private set; }
        #endregion
    }

    public sealed class CWorld : CBase
    {
        #region ctor
        internal CWorld(CBase aParent) : base(aParent)
        {
            // this.AvatarCoords = new CWorldPos(0, 0, 0);

            var aScale = 1;
            this.TileEdgeLen = 1.0d * aScale;
            this.TileEdgeLens = new CWorldPos(this.TileEdgeLen);
            this.TileBumperCountMin = 10;
            this.TileBumperCountMax = 50;
            this.BumperRadiusMax = 0.051d * aScale;
            this.BumperGravityRadiusMax = 1.0d;
            this.BumperGravityStrengthMax = 1.0d;

            var aBorder = (this.Cube.EdgeLength - 1) / 2;
            this.MinCubeCoord = Int64.MinValue;
            this.MaxCubeCoord = Int64.MaxValue;
            //var aUseDouble3d = false;
            //this.MaxCubeCoord = aUseDouble3d
            //                  ? (Int64)(Int64.MaxValue - 1)
            //                  : (Int64)(UInt32.MaxValue - 1)
            //                  ;
            this.MinInSpaceCubeCoord = this.MinCubeCoord + aBorder;
            this.MaxInSpaceCubeCoord = this.MaxCubeCoord - aBorder;
            this.MinAvatarCoord = aBorder;
            this.MaxAvatarCoord = this.MaxCubeCoord - aBorder;

            this.MaxCubePos = this.Cube.NewCoords(this.MaxCubeCoord);
        }
        public override void Load()
        {
            base.Load();
            this.Cube.Load();
        }
        public override T Throw<T>(Exception aException)
           => aException.Throw<T>();

        internal readonly Int64 MaxInSpaceCubeCoord;
        internal readonly Int64 MinInSpaceCubeCoord;
        internal readonly Int64 MaxCubeCoord;
        internal readonly Int64 MinCubeCoord;
        internal readonly Int64 MinAvatarCoord;
        internal readonly Int64 MaxAvatarCoord;

        //internal double MinWorldCoord => this.MinCubeCoord * this.TileEdgeLen;
        //internal double MaxWorldCoord => this.MaxCubeCoord * this.TileEdgeLen;

        internal bool IsBeyound(CTile aTile)
        {
            return false;
            //var aCubeCoordinates = aTile.AbsoluteCubeCoordinates;
            //var aIsBorder = (from aCoordinate in aCubeCoordinates
            //                 select aCoordinate <  this.MinInSpaceCubeCoord
            //                 || aCoordinate >  this.MaxInSpaceCubeCoord).Contains(true);
            //return aIsBorder;
        }
        #endregion
        #region Cube
        private CCube CubeM;
        internal CCube Cube => CLazyLoad.Get(ref this.CubeM, () => CCube.New(this));
        #endregion
        #region ServiceContainer
        private CServiceContainer ServiceContainerM;
        public override CServiceContainer ServiceContainer => CLazyLoad.Get(ref this.ServiceContainerM, this.NewServiceContainer);

        internal bool AvatarAbsCoordIsValid(CCubePos aCoords)
        {
            throw new NotImplementedException();
            //var aBeyound = (from aCoordinate in aCoords
            //                 select aCoordinate < this.MinAvatarCoord
            //                 || aCoordinate > this.MaxAvatarCoord).Contains(true);
            //return !aBeyound;
        }
        private CServiceContainer NewServiceContainer()
        {
            var aServiceContainer = base.ServiceContainer.Inherit(this);
            aServiceContainer.AddService<CWorld>(() => this);
            return aServiceContainer;
        }
        #endregion
        #region Draw
        internal void Draw()
        {
            this.Cube.Draw();
        }
        #endregion
        public readonly double TileEdgeLen;
        internal readonly CWorldPos TileEdgeLens;

        internal CWorldPos GetWorldPos(CTile aTile)
           => this.GetWorldPos(aTile.AbsoluteCubeCoordinates);

        internal CWorldPos NewCoords(double xyz)
            => new CWorldPos(xyz);

        internal readonly CCubePos MaxCubePos;

        internal CWorldPos GetWorldPos(CCubePos aCubeCoordinates)
           => this.GetWorldPos2(aCubeCoordinates); // .Subtract(this.CubeCenterOffset)

        internal CWorldPos GetWorldPos2(CCubePos aCubeCoordinates)
            => aCubeCoordinates.ToWorldPos() * this.TileEdgeLens;

        public CCubePos GetCubePos(CWorldPos aWorldPos)
            => aWorldPos.Divide(this.TileEdgeLens).ToCubePos();
        //internal CCubePos CubeCenterOffset
        //    => CCubePos.NewN((this.Cube.Depth - 1) / 2, (int)this.Cube.Depth);
        ////    => new CCubePos((Int64)aWorldPos[0], (Int64)aWorldPos[1], (Int64)aWorldPos[2]); //.Add(this.CubeCenterOffset);

        internal readonly int TileBumperCountMin;
        internal readonly int TileBumperCountMax;
        internal readonly double BumperRadiusMax;
        internal readonly double BumperGravityRadiusMax;
        internal readonly double BumperGravityStrengthMax;
        public bool QuadrantGridLines = true;
        //internal CWorldPos GetQuadrantPosition(CTile aTile)

        //public bool GetCubeCoordinatesIsDefined(CWorldPos aWorldCoordinates)
        //    => throw new NotImplementedException();
        //=> aWorldCoordinates.x >= this.MinWorldCoord && aWorldCoordinates[0] <= this.MaxWorldCoord
        //&& aWorldCoordinates.y >= this.MinWorldCoord && aWorldCoordinates[1] <= this.MaxWorldCoord
        //&& aWorldCoordinates.z >= this.MinWorldCoord && aWorldCoordinates[2] <= this.MaxWorldCoord;


        internal CWorldFrameInfo WorldFrameInfo;

        public void RefreshFrameInfo(CWorldPos aWorldPos)
        {
            this.WorldFrameInfo = new CWorldFrameInfo(this, aWorldPos);

            foreach(var aSpriteData in this.WorldFrameInfo.SpriteDatas)
            {
                aSpriteData.RefreshFrameInfo();
            }
        }
    }
}


namespace CharlyBeck.Mvi.World
{
    using CSpriteDistance = Tuple<CSpriteData, double>;
    internal sealed class CWorldFrameInfo
    {
        internal CWorldFrameInfo(CWorld aWorld, CWorldPos aWorldPos)
        {
            this.World = aWorld;
            this.WorldPos = aWorldPos;
            this.SpriteDatas = (from aTile in aWorld.Cube.Tiles from aSpriteData in aTile.TileDataLoadProxy.Loaded.TileDescriptor.SpriteDatas select aSpriteData).ToArray();
            this.SpriteDistances = (from aSpriteData in this.SpriteDatas select new Tuple<CSpriteData, double>(aSpriteData, CWorldPos.Distance(aWorldPos, aSpriteData.WorldPos))).ToArray().OrderBy(aDist=>aDist.Item1).ToArray();
        }

        internal readonly CWorld World;
        internal readonly CWorldPos WorldPos;
        internal CSpriteData[] SpriteDatas;
        internal CSpriteDistance[] SpriteDistances;

    }


}