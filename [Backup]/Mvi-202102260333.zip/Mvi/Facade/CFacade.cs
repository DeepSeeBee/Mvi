﻿using CharlyBeck.Mvi.Cube;
using CharlyBeck.Mvi.World;
using CharlyBeck.Utils3.ServiceLocator;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharlyBeck.Mvi.Facade
{
    public interface ISprite
    {
        void Update(BitArray aWhat);
        void Draw();
        void Unload();

        CSpriteData SpriteData { get; }
    }

    public interface ISprite<T> : ISprite
    {

    }


    public abstract class CFacade
    {
        public CFacade()
        {
            this.RootBase.ServiceContainer.AddService<CFacade>(() => this);
            this.World = new CWorld(this.RootBase);
        }
        public virtual void Init()
        {
            this.World.Load();
        }
        public virtual void Load()
        {
            this.World.Load();
        }
        private readonly CBase RootBase = new CRootBase(CRootBase.NoParent);
        public readonly CWorld World;
        internal CCube Cube => this.World.Cube;
        public abstract ISprite<T> NewSprite<T>(T aSpriteData);


        public void Draw()
           => this.World.Draw();

        public void SetCubeCoordinates(CCoordinates<Int64> aCoordinates)
        {
            this.Cube.MoveToCubeCoordinatesOnDemand(aCoordinates);
        }
    }

}
