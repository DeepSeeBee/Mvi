﻿using CharlyBeck.Mvi.Cube;
using CharlyBeck.Mvi.Facade;
using CharlyBeck.Utils3.Exceptions;
using CharlyBeck.Utils3.LazyLoad;
using CharlyBeck.Utils3.ServiceLocator;
using CharlyBeck.Mvi.World;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using CharlyBeck.Utils3.Enumerables;

namespace CharlyBeck.Mvi.Cube
{
    partial class CTileDataLoadProxy
    {
        #region TileBuilder
        private CTileBuilder TileBuilderM;
        internal CTileBuilder TileBuilder => CLazyLoad.Get(ref this.TileBuilderM, () => new CTileBuilder(this));
        internal override CLoadedTileData NewLoaded()
              => this.TileBuilder.NewLoadedTileData(this);
        #endregion
    }
}
namespace CharlyBeck.Mvi.World
{

    internal abstract class CWorldTileDescriptor : CTileDescriptor
    {
        #region ctor
        internal CWorldTileDescriptor(CTileBuilder aTileBuilder) : base(aTileBuilder)
        {
        }
        #endregion

    }

    internal abstract class CQuadrantTileDescriptor : CWorldTileDescriptor
    {
        #region ctor
        internal CQuadrantTileDescriptor(CTileBuilder aTileBuilder) : base(aTileBuilder)
        {
            this.QuadrantSpriteData = new CQuadrantSpriteData(aTileBuilder, this);
        }
        #endregion

        internal readonly CQuadrantSpriteData QuadrantSpriteData;

        internal override void Draw()
        {
            base.Draw();
            this.QuadrantSpriteData.Draw();
        }
    }


    public sealed class CBeyoundSpaceSpriteData : CSpriteData
    {
        internal CBeyoundSpaceSpriteData(CTileBuilder aTileBuilder, CTileDescriptor aTileDescriptor) : base(aTileBuilder, aTileDescriptor)
        {
            this.Init();
        }
        internal override ISprite NewSprite()
            => this.NewSprite(this);
    }

    internal sealed class CBeyoundSpaceTileDescriptor : CQuadrantTileDescriptor
    {
        #region ctor
        internal CBeyoundSpaceTileDescriptor(CTileBuilder aTileBuilder) : base(aTileBuilder)
        {
            this.BeyoundSpaceSprite = new CBeyoundSpaceSpriteData(aTileBuilder, this);
        }
        #endregion
        private readonly CBeyoundSpaceSpriteData BeyoundSpaceSprite;

    }

    internal sealed class CInSpaceTileDescriptor : CQuadrantTileDescriptor
    {
        #region ctor
        internal CInSpaceTileDescriptor(CTileBuilder aTileBuilder) : base(aTileBuilder)
        {
            var aWorldGenerator = aTileBuilder.WorldGenerator;
            var aWorld = aTileBuilder.World;
            var aBumperCount = aWorldGenerator.NextInteger(aWorld.TileBumperCountMin, aWorld.TileBumperCountMax);
            var aBumpers = new CBumperSpriteData[aBumperCount];
            for (var aIdx = 0; aIdx < aBumperCount; ++aIdx)
                aBumpers[aIdx] = new CBumperSpriteData(aTileBuilder, this);
            this.Bumpers = aBumpers;
        }
        internal override void Draw()
        {
            base.Draw();

            foreach (var aBumper in this.Bumpers)
                aBumper.Draw();
        }
        internal CBumperSpriteData[] Bumpers;
        #endregion
    }

    internal sealed class CWorldGenerator : CRandomGenerator
    {
        #region ctor
        internal CWorldGenerator(CBase aParent) : base(aParent)
        {
            this.Init();
        }
        public override T Throw<T>(Exception aException)
           => aException.Throw<T>();


        #endregion
    }

    public abstract class CSpriteData
    {
        internal CSpriteData(CTileBuilder aTileBuilder, CTileDescriptor aTileDescriptor)
        {
            this.WorldGenerator = aTileBuilder.WorldGenerator;
            this.Facade = aTileBuilder.Facade;
            this.Changes = new BitArray(this.ChangesCount);
            this.AbsoluteCubeCoordinates = aTileBuilder.Tile.AbsoluteCubeCoordinates;
            aTileDescriptor.SpriteDatas.Add(this);
        }
        internal virtual void Init()
        {
            this.Sprite = this.NewSprite();
            this.Update();
        }

        public readonly CCoordinates<Int64> AbsoluteCubeCoordinates;

        internal readonly CFacade Facade;
        internal CWorld World => this.Facade.World;
        internal readonly CWorldGenerator WorldGenerator;
        internal abstract ISprite NewSprite();
        internal ISprite<TData> NewSprite<TData>(TData aData) 
            => this.Facade.NewSprite<TData>(aData);
        internal virtual int ChangesCount => 0;
        internal ISprite Sprite { get; private set; }
        internal readonly BitArray Changes;
        internal void Update()
        {
            if(this.Sprite is object)
            {
                this.Sprite.Update(this.Changes);
            }
            this.Changes.SetAll(false);
        }

        internal virtual bool Visible => true;
        internal void Draw()
        {
            if (this.Visible)
            {
                this.Sprite.Draw();
            }
        }

        internal void Unload()
        {
            if(this.Sprite is object)
            { 
                this.Sprite.Unload();
            }
        }
    }

    public static class CExtensions
    {
        public static IEnumerable<CCoordinates<double>> PolyPointsToLines(this IEnumerable<CCoordinates<double>> aSquare)
        {
            var aFirst = aSquare.First();
            var aPrevious = aSquare.First();
            foreach (var aPoint in aSquare.Skip(1))
            {
                yield return aPrevious;
                yield return aPoint;
                aPrevious = aPoint;
            }
            yield return aPrevious;
            yield return aFirst;
        }

    }

    public sealed class CQuadrantSpriteData : CSpriteData
    {
        internal CQuadrantSpriteData(CTileBuilder aTileBuilder, CTileDescriptor aTileDescriptor) : base(aTileBuilder, aTileDescriptor)
        {
            var aTile = aTileBuilder.Tile;
            var aWorld = aTileBuilder.World;
            var aSize2 = aWorld.TileSize2;

            this.Coordinates2 = aWorld.GetWorldPos(aTile);
            this.Size2 = aSize2;

            this.FrontBottomLeft2 = new CCoordinates<double>(this.Coordinates2[0], this.Coordinates2[1], this.Coordinates2[2]);
            this.FrontTopLeft2 = new CCoordinates<double>(this.Coordinates2[0], this.Coordinates2[1] + aSize2, this.Coordinates2[2]);
            this.FrontTopRight2 = new CCoordinates<double>(this.Coordinates2[0] + aSize2, this.Coordinates2[1] + aSize2, this.Coordinates2[2]);
            this.FrontBottomRight2 = new CCoordinates<double>(this.Coordinates2[0] + aSize2, this.Coordinates2[1], this.Coordinates2[2]);

            this.BackBottomLeft2 = new CCoordinates<double>(this.Coordinates2[0], this.Coordinates2[1], this.Coordinates2[2] + aSize2);
            this.BackTopLeft2 = new CCoordinates<double>(this.Coordinates2[0], this.Coordinates2[1] + aSize2, this.Coordinates2[2] + aSize2);
            this.BackTopRight2 = new CCoordinates<double>(this.Coordinates2[0] + aSize2, this.Coordinates2[1] + aSize2, this.Coordinates2[2] + aSize2);
            this.BackBottomRight2 = new CCoordinates<double>(this.Coordinates2[0] + aSize2, this.Coordinates2[1], this.Coordinates2[2] + aSize2);

            this.Init();
        }
        internal override ISprite NewSprite()
           => this.NewSprite<CQuadrantSpriteData>(this);
        internal override int ChangesCount => 0;

        public readonly CCoordinates<double> Coordinates2;
        public readonly double Size2;

        public readonly CCoordinates<double> FrontBottomLeft2;
        public readonly CCoordinates<double> FrontTopLeft2;
        public readonly CCoordinates<double> FrontTopRight2;
        public readonly CCoordinates<double> FrontBottomRight2;
        public readonly CCoordinates<double> BackBottomLeft2;
        public readonly CCoordinates<double> BackTopLeft2;
        public readonly CCoordinates<double> BackTopRight2;
        public readonly CCoordinates<double> BackBottomRight2;

        internal override bool Visible => this.World.QuadrantGridLines;
        public IEnumerable<CCoordinates<double>> FrontSquare2
        {
            get
            {
                yield return this.FrontBottomLeft2;
                yield return this.FrontTopLeft2;
                yield return this.FrontTopRight2;
                yield return this.FrontBottomRight2;
            }
        }


        public IEnumerable<CCoordinates<double>> BackSquare2
        {
            get
            {
                yield return this.BackBottomLeft2;
                yield return this.BackTopLeft2;
                yield return this.BackTopRight2;
                yield return this.BackBottomRight2;
            }
        }

        public IEnumerable<CCoordinates<double>> TopSquare2
        {
            get
            {
                yield return this.FrontTopLeft2;
                yield return this.BackTopLeft2;
                yield return this.BackTopRight2;
                yield return this.FrontTopRight2;
            }
        }

        public IEnumerable<CCoordinates<double>> BottomSquare2
        {
            get
            {
                yield return this.FrontBottomLeft2;
                yield return this.BackBottomLeft2;
                yield return this.BackBottomRight2;
                yield return this.FrontBottomRight2;
            }
        }

        public IEnumerable<CCoordinates<double>> LeftSquare2
        {
            get
            {
                yield return this.FrontBottomLeft2;
                yield return this.FrontTopLeft2;
                yield return this.BackTopLeft2;
                yield return this.BackBottomLeft2;
            }
        }

        public IEnumerable<CCoordinates<double>> RightSquare2
        {
            get
            {
                yield return this.FrontBottomRight2;
                yield return this.FrontTopRight2;
                yield return this.BackTopRight2;
                yield return this.BackBottomRight2;
            }
        }



        public IEnumerable<CCoordinates<double>> Lines2
        {
            get
            {
                //yield return this.FrontBottomLeft;
                //yield return this.FrontBottomRight;
                //              yield return this.FrontBottomLeft;
                //                yield return this.FrontTopLeft;#

                foreach (var aPoint in this.FrontSquare2.PolyPointsToLines()) //.Subset(2,4))
                    yield return aPoint;
                foreach (var aPoint in this.BackSquare2.PolyPointsToLines())
                    yield return aPoint;
                foreach (var aPoint in this.LeftSquare2.PolyPointsToLines())
                    yield return aPoint;
                foreach (var aPoint in this.TopSquare2.PolyPointsToLines())
                    yield return aPoint;
                foreach (var aPoint in this.RightSquare2.PolyPointsToLines())
                    yield return aPoint;
                foreach (var aPoint in this.BottomSquare2.PolyPointsToLines())
                    yield return aPoint;
            }
        }
    }

    public sealed class CBumperSpriteData : CSpriteData
    {
        internal CBumperSpriteData(CTileBuilder aTileBuilder, CTileDescriptor aTileDescriptor) : base(aTileBuilder, aTileDescriptor)
        {
            var aWorldGenerator = aTileBuilder.WorldGenerator;
            var aWorld = aTileBuilder.World;
            var aTile = aTileBuilder.Tile;
            var aTileAbsoluteCubeCoordinates = aTile.AbsoluteCubeCoordinates;
            this.Coordinates2 = aWorld.GetWorldPos(aTileAbsoluteCubeCoordinates).Add(aWorldGenerator.NextDouble(aWorld.TileSizePos));
            this.Radius = aWorldGenerator.NextDouble(aWorld.BumperRadiusMax);
            this.Color = aWorldGenerator.NextDouble(3);
            this.AccelerateEnums = aWorldGenerator.NextEnums<CAccelerateEnum>();
            this.GravityIsEnabled = this.AccelerateEnums.Contains(CAccelerateEnum.Gravity);
            this.GravityRadius = aWorldGenerator.NextDouble(aWorld.BumperGravityRadiusMax);
            this.GravityStrength = aWorldGenerator.NextDouble(aWorld.BumperGravityStrengthMax);
            this.GravityRepulsive = aWorldGenerator.NextBoolean();
            this.AccelerateIsEnabled = this.AccelerateEnums.Contains(CAccelerateEnum.Accelerate);
            this.AccelerateHasVector = aWorldGenerator.NextBoolean();
            this.AccelerateVector = aWorldGenerator.NextDouble(3);
            this.AccelerateStrength = aWorldGenerator.NextDouble(1.0d);
            this.AccelerateIsRepulsive = aWorldGenerator.NextBoolean();

            this.Init();
        }

        internal override ISprite NewSprite()
           => this.Facade.NewSprite(this);
        internal override int ChangesCount => (int)CChangeEnum._Count;

        public readonly CCoordinates<double> Coordinates2;
        public readonly double Radius;
        public readonly CCoordinates<double> Color;
        internal readonly CAccelerateEnum[] AccelerateEnums;
        public readonly bool GravityIsEnabled;
        public readonly double GravityRadius;
        public readonly double GravityStrength;
        public readonly bool GravityRepulsive;
        public readonly bool AccelerateIsEnabled;
        public readonly bool AccelerateHasVector;
        public readonly CCoordinates<double> AccelerateVector;
        public readonly double AccelerateStrength;
        public readonly bool AccelerateIsRepulsive;


        internal enum CChangeEnum
        {
            _Count
        }


        internal enum CAccelerateEnum
        {
            Gravity,
            Accelerate
        }
    }

    internal sealed class CTileBuilder : CBase
    {
        #region ctor
        internal CTileBuilder(CBase aParent) : base(aParent)
        {
            this.WorldGenerator = new CWorldGenerator(this);
            this.Facade = this.ServiceContainer.GetService<CFacade>();
            this.Init();
        }
        public override T Throw<T>(Exception aException)
           => aException.Throw<T>();
        #endregion
        #region Tile
        private CTile TileM;
        internal CTile Tile => CLazyLoad.Get(ref this.TileM, () => this.ServiceContainer.GetService<CTile>());
        #endregion
        #region TileDescriptor
        internal CTileDescriptor NewTileDescriptor()
        {

            var aWorld = this.World;
            var aTile = this.Tile;
            //System.Diagnostics.Debug.Print("NewTileDescriptor: " + aTile.AbsoluteCubeCoordinates.ToString());
            var aIsBeyound = aWorld.IsBeyound(aTile);
            var aWorldGenerator = this.WorldGenerator;
            aWorldGenerator.Reset(aTile);
            if (aIsBeyound)
            {
                System.Diagnostics.Debug.Print("NewTileDescriptor: CBeyoundSpaceTileDescriptor" + aTile.AbsoluteCubeCoordinates.ToString());
                var aTileDescriptor = new CBeyoundSpaceTileDescriptor(this);
                return aTileDescriptor;
            }
            else
            {
                var aTileDescriptor = new CInSpaceTileDescriptor(this);
                return aTileDescriptor;
            }
        }

        internal CLoadedTileData NewLoadedTileData(CTileDataLoadProxy aTileDataLoadProxy)
           => CLoadedTileData.New(this, this.NewTileDescriptor());
        #endregion
        #region World
        private CWorld WorldM;
        internal CWorld World => CLazyLoad.Get(ref this.WorldM, () => this.ServiceContainer.GetService<CWorld>());
        #endregion
        #region WorldGenerator
        internal readonly CWorldGenerator WorldGenerator;
        #endregion
        #region Facade
        internal CFacade Facade { get; private set; }
        #endregion
    }

    public sealed class CWorld : CBase
    {
        #region ctor
        internal CWorld(CBase aParent) : base(aParent)
        {
           // this.AvatarCoords = new CCoordinates<double>(0, 0, 0);

            var aScale = 1;
            this.TileSize2 = 1.0d * aScale;
            this.TileSizePos = CCoordinates<double>.NewN(this.TileSize2, 3);
            this.TileBumperCountMin = 10;
            this.TileBumperCountMax = 100;
            this.BumperRadiusMax = 0.01d * aScale;
            this.BumperGravityRadiusMax = 1.0d;
            this.BumperGravityStrengthMax = 1.0d;

            var aBorder = (this.Cube.EdgeLength - 1) / 2;
            this.MinCubeCoord = Int64.MinValue;
            this.MaxCubeCoord = Int64.MaxValue;
            //var aUseDouble3d = false;
            //this.MaxCubeCoord = aUseDouble3d
            //                  ? (Int64)(Int64.MaxValue - 1)
            //                  : (Int64)(UInt32.MaxValue - 1)
            //                  ;
            this.MinInSpaceCubeCoord = this.MinCubeCoord + aBorder;
            this.MaxInSpaceCubeCoord = this.MaxCubeCoord - aBorder;
            this.MinAvatarCoord = aBorder;
            this.MaxAvatarCoord =  this.MaxCubeCoord-  aBorder;

            this.MaxCubePos = this.Cube.NewCoords(this.MaxCubeCoord);
        }
        public override void Load()
        {
            base.Load();
            this.Cube.Load();
        }
        public override T Throw<T>(Exception aException)
           => aException.Throw<T>();

        internal readonly Int64 MaxInSpaceCubeCoord;
        internal readonly Int64 MinInSpaceCubeCoord;
        internal readonly Int64 MaxCubeCoord;
        internal readonly Int64 MinCubeCoord;
        internal readonly Int64 MinAvatarCoord;
        internal readonly Int64 MaxAvatarCoord;

        internal double MinWorldCoord => this.MinCubeCoord * this.TileSize2;
        internal double MaxWorldCoord => this.MaxCubeCoord * this.TileSize2;

        internal bool IsBeyound(CTile aTile)
        {
            return false;
            //var aCubeCoordinates = aTile.AbsoluteCubeCoordinates;
            //var aIsBorder = (from aCoordinate in aCubeCoordinates
            //                 select aCoordinate <  this.MinInSpaceCubeCoord
            //                 || aCoordinate >  this.MaxInSpaceCubeCoord).Contains(true);
            //return aIsBorder;
        }
        #endregion
        #region Cube
        private CCube CubeM;
        internal CCube Cube => CLazyLoad.Get(ref this.CubeM, () => CCube.New(this));
        #endregion
        #region ServiceContainer
        private CServiceContainer ServiceContainerM;
        public override CServiceContainer ServiceContainer => CLazyLoad.Get(ref this.ServiceContainerM, this.NewServiceContainer);

        internal bool AvatarAbsCoordIsValid(CCoordinates<Int64> aCoords)
        {
            var aBeyound = (from aCoordinate in aCoords
                             select aCoordinate < this.MinAvatarCoord
                             || aCoordinate > this.MaxAvatarCoord).Contains(true);
            return !aBeyound;
        }
        private CServiceContainer NewServiceContainer()
        {
            var aServiceContainer = base.ServiceContainer.Inherit(this);
            aServiceContainer.AddService<CWorld>(() => this);
            return aServiceContainer;
        }
        #endregion
        #region Draw
        internal void Draw()
        {
            this.Cube.Draw();
        }
        #endregion
        public readonly double TileSize2;
        internal readonly CCoordinates<double> TileSizePos;

        internal CCoordinates<double> GetWorldPos(CTile aTile)
           => this.GetWorldPos(aTile.AbsoluteCubeCoordinates);

        private CCoordinates<double> TileSizeM;
        private CCoordinates<double> TileSize
            => CLazyLoad.Get(ref this.TileSizeM, () => this.NewCoords(this.TileSize2)); // => CCoordinates<double>.NewN(this.TileSize2, (int)this.Cube.Depth));

        internal CCoordinates<double> NewCoords(double aCoord)
            => CCoordinates<double>.NewN(aCoord, 3);

        internal readonly CCoordinates<Int64> MaxCubePos;

        internal CCoordinates<double> GetWorldPos(CCoordinates<Int64> aCubeCoordinates)
           => this.GetWorldPos2(aCubeCoordinates); // .Subtract(this.CubeCenterOffset)

        internal CCoordinates<double> GetWorldPos2(CCoordinates<Int64> aCubeCoordinates)
            => aCubeCoordinates.ToDouble().Multiply(this.TileSizePos); 

        public CCoordinates<Int64> GetCubePos(CCoordinates<double> aWorldPos)
            => aWorldPos.Divide(this.TileSizePos).ToInt64();
        //internal CCoordinates<Int64> CubeCenterOffset
        //    => CCoordinates<Int64>.NewN((this.Cube.Depth - 1) / 2, (int)this.Cube.Depth);
        ////    => new CCoordinates<Int64>((Int64)aWorldPos[0], (Int64)aWorldPos[1], (Int64)aWorldPos[2]); //.Add(this.CubeCenterOffset);

        internal readonly int TileBumperCountMin;
        internal readonly int TileBumperCountMax;
        internal readonly double BumperRadiusMax;
        internal readonly double BumperGravityRadiusMax;
        internal readonly double BumperGravityStrengthMax;
        public bool QuadrantGridLines = true;
        //internal CCoordinates<double> GetQuadrantPosition(CTile aTile)

        public bool GetCubeCoordinatesIsDefined(CCoordinates<double> aWorldCoordinates)
            => aWorldCoordinates[0] >= this.MinWorldCoord && aWorldCoordinates[0] <= this.MaxWorldCoord
            && aWorldCoordinates[1] >= this.MinWorldCoord && aWorldCoordinates[1] <= this.MaxWorldCoord
            && aWorldCoordinates[2] >= this.MinWorldCoord && aWorldCoordinates[2] <= this.MaxWorldCoord;
    }


}
