﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharlyBeck.Utils3.LazyLoad
{
   public static class CLazyLoad
   {
      public static T Get<T>(ref T aVar, Func<T> aLoad)
      {
         if (!(aVar is T))
         {
            aVar = aLoad();
         }
         return aVar;      
      }

      public static void Load(this object aObject)
      { }

   }
}
