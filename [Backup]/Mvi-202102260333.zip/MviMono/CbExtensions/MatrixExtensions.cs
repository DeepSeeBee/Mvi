﻿using Microsoft.Xna.Framework;
using System;

namespace CharlyBeck.Mvi.XnaExtensions
{
    internal static class MatrixExtensions
    {
        internal static Vector3 Transform(this Matrix m, Vector3 v)
            => new Vector3((v.X * m[0, 0] + v.Y * m[0, 1] + v.Z * m[0, 2] + m[0, 3]),
                           (v.X * m[1, 0] + v.Y * m[1, 1] + v.Z * m[1, 2] + m[1, 3]),
                           (v.X * m[2, 0] + v.Y * m[2, 1] + v.Z * m[2, 2] + m[2, 3]));

        internal static Vector3 RotateZ(this Vector3 aRotated, float aRadians)
            => Matrix.CreateRotationZ(aRadians).Transform(aRotated);

        internal static Vector3 RotateZ(this Vector3 aRotated, Vector3 aCenter, float aRadians)
            => (aRotated - aCenter).RotateZ(aRadians) + aCenter;

        internal static Vector3 RotateY(this Vector3 aRotated, float aRadians)
            => Matrix.CreateRotationY(aRadians).Transform(aRotated);

        internal static Vector3 RotateY(this Vector3 aRotated, Vector3 aCenter, float aRadians)
            => (aRotated - aCenter).RotateY(aRadians) + aCenter;

        internal static Vector3 RotateX(this Vector3 aRotated, float aRadians)
            => Matrix.CreateRotationX(aRadians).Transform(aRotated);

        internal static Vector3 RotateX(this Vector3 aRotated, Vector3 aCenter, float aRadians)
            => (aRotated - aCenter).RotateX(aRadians) + aCenter;

        internal static float GetLength(this Vector3 aPoint) // Not tested, https://www.engineeringtoolbox.com/distance-relationship-between-two-points-d_1854.html
            => (float)Math.Sqrt((aPoint.X * aPoint.X) + (aPoint.Y * aPoint.Y) + (aPoint.Z * aPoint.Z));

       internal static Vector3 MakeLongerDelta(this Vector3 aVector, float aLength) // Not tested, https://www.freemathhelp.com/forum/threads/extend-length-of-line-in-3d-space-find-new-end-point.125160/
            => (new Vector3(aLength) / new Vector3(aVector.GetLength())) * aVector;

        internal static Vector3 MakeLonger(this Vector3 aVector, float aLength)
            => aVector + aVector.MakeLongerDelta(aLength);
        
    }
}
