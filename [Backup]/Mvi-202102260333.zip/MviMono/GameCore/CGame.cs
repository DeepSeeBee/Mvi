﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
//using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Input;

namespace CharlyBeck.Mvi.Mono.GameCore
{
    using CharlyBeck.Mvi.Cube;
    using CharlyBeck.Mvi.Facade;
    using CharlyBeck.Mvi.XnaExtensions;
    using CharlyBeck.Mvi.World;
    using CharlyBeck.Utils3.Enumerables;
    using CharlyBeck.Utils3.Exceptions;
    using CharlyBeck.Utils3.LazyLoad;
    using CharlyBeck.Utils3.ServiceLocator;
    using System.Collections;
    using System.IO;

    internal abstract class CBase : CServiceLocatorNode
    {
        internal CBase(CBase aParent) : base(aParent)
        {
        }
        internal CBase(CNoParentEnum aNoParent) : base(aNoParent)
        {
        }
    }
    internal sealed class CRootBase : CBase
    {
        internal CRootBase() : base(NoParent)
        {
        }
        public override T Throw<T>(Exception aException)
           => aException.Throw<T>();
    }

    internal abstract class CSprite
    :
        CBase
    ,   ISprite
    {
        #region ctor
        internal CSprite(CBase aParent, CMonoFacade aMonoFacade, CSpriteData aSpriteData) : base(aParent)
        {
            this.MonoFacade = aMonoFacade;

            var aGame = this.Game;
            this.UpdateBasicEffect();

            this.Game.AvatarChanged += this.UpdateBasicEffect;
        }
        private CSpriteData SpriteDataM;
        public CSpriteData SpriteData { get => this.SpriteDataM; }

        void ISprite.Unload()
            => this.Delete();
        protected virtual void Delete()
        {
            this.Game.AvatarChanged -= this.UpdateBasicEffect;
        }
        #endregion
        internal readonly CMonoFacade MonoFacade;
        internal CGame Game => this.MonoFacade.Game;
        internal GraphicsDevice GraphicsDevice => this.Game.GraphicsDevice;

        #region BasicEffect
        private BasicEffect BasicEffect;
        private void UpdateBasicEffect()
        {
            var aGame = this.Game;
            this.BasicEffect = aGame.BasicEffect;
            //this.BasicEffect.Alpha = 1f;
            //this.BasicEffect.VertexColorEnabled = true;
            //this.BasicEffect.World = aGame.WorldMatrix;
            //this.BasicEffect.View = aGame.ViewMatrix; //  * Matrix.CreateScale(0.01f);
            //this.BasicEffect.Projection = aGame.ProjectionMatrix;
        }
        #endregion
        #region Update
        internal virtual void Update(BitArray aChanged) { }
        void ISprite.Update(BitArray aChanged)
           => this.Update(aChanged);
        #endregion
        #region Draw
        internal virtual void DrawPrimitives() { }
        internal virtual void Draw()
        {
            this.UpdateBasicEffect();
            foreach (var aEffectPass in this.BasicEffect.CurrentTechnique.Passes)
            {
                aEffectPass.Apply();
                this.DrawPrimitives();
            }
        }
        void ISprite.Draw()
           => this.Draw();
        #endregion

    }

    internal abstract class CSprite<T>
    :
       CSprite
    , ISprite<T>
    {
        internal CSprite(CBase aParent, CMonoFacade aMonoFacade, CSpriteData aSpriteData) : base(aParent, aMonoFacade, aSpriteData)
        {
        }
    }
    internal sealed class CQuadrantSprite
    :
       CSprite<CQuadrantSpriteData>
    {
        internal CQuadrantSprite(CBase aParent, CMonoFacade aMonoFacade, CQuadrantSpriteData aQuadrantSpriteData) : base(aParent, aMonoFacade, aQuadrantSpriteData)
        {
            this.QuadrantSpriteData = aQuadrantSpriteData;
            var aGraphicDevice = this.GraphicsDevice;


            var aUseGridLines = true;
            if (aUseGridLines)
            {
                var aVertexPositionColor = aQuadrantSpriteData.Lines2.ToVector3().ToVertexPositionColor(Color.White);
                this.LinesVertexBuffer2 = aVertexPositionColor.ToVertexBuffer(aGraphicDevice);
            }

            var aUseCornerTriangles = false;
            if(aUseCornerTriangles)
            {
                var aTriangleStripes = new VertexPositionColor[]
                {
                    new VertexPositionColor(aQuadrantSpriteData.FrontBottomLeft2.ToVector3(), Color.White.SetAlpha(0.2f)),
                    new VertexPositionColor(aQuadrantSpriteData.FrontTopLeft2.ToVector3(), Color.White.SetAlpha(0.2f)),
                    new VertexPositionColor(aQuadrantSpriteData.FrontBottomRight2.ToVector3(), Color.White.SetAlpha(0.2f)),
                };
                this.TriangleStripesVertexBuffer = aTriangleStripes.ToVertexBuffer(aGraphicDevice);
            }
        }

        internal readonly VertexBuffer TriangleStripesVertexBuffer;

        public override T Throw<T>(Exception aException)
           => aException.Throw<T>();

        internal readonly VertexBuffer LinesVertexBuffer2;
        internal readonly CQuadrantSpriteData QuadrantSpriteData;

        internal override void DrawPrimitives()
        {
            base.DrawPrimitives();
            var aGraphicsDevice = this.GraphicsDevice;

            if(this.LinesVertexBuffer2 is object)
            { 
                aGraphicsDevice.SetVertexBuffer(this.LinesVertexBuffer2);
                aGraphicsDevice.DrawPrimitives(PrimitiveType.LineList, 0, this.LinesVertexBuffer2.VertexCount / 2);
            }
            if(this.TriangleStripesVertexBuffer is object)
            {
                aGraphicsDevice.SetVertexBuffer(this.TriangleStripesVertexBuffer);
                aGraphicsDevice.DrawPrimitives(PrimitiveType.TriangleList, 0, this.TriangleStripesVertexBuffer.VertexCount / 3);
            }
        }


    }

    internal static class CExtensions
    {
        internal static IEnumerable<VertexPositionColor> ToVertexPositionColor(this IEnumerable<Vector3> aVector3s, Color aColor)
            => from aVector3 in aVector3s select new VertexPositionColor(aVector3, aColor);
        internal static Vector3 ToVector3(this CCoordinates<double> aVector)
            => new Vector3((float)aVector[0], (float)aVector[1], (float)aVector[2]);

        internal static IEnumerable<Vector3> ToVector3(this IEnumerable<CCoordinates<double>> aCoordinates)
            => from aCoordinate in aCoordinates select aCoordinate.ToVector3();
        internal static IEnumerable<VertexPosition> ToVertexPosition(this IEnumerable<Vector3> aVectors)
            => from aVector in aVectors select new VertexPosition(aVector);
        internal static IEnumerable<VertexPosition> ToVertexPosition(this IEnumerable<CCoordinates<double>> aCoordinates)
            => aCoordinates.ToVector3().ToVertexPosition();
        internal static VertexBuffer ToVertexBuffer<T>(this IEnumerable<T> aItems, GraphicsDevice aGraphicDevice, BufferUsage aBufferUsage = BufferUsage.WriteOnly) where T : struct
        {
            var aItemArray = aItems.ToArray();
            var aVertexBuffer = new VertexBuffer(aGraphicDevice, typeof(T), aItemArray.Length, aBufferUsage);
            aVertexBuffer.SetData<T>(aItemArray);
            return aVertexBuffer;
        }
        internal static VertexBuffer ToVertexPositionBuffer(this IEnumerable<CCoordinates<double>> aItems, GraphicsDevice aGraphicDevice, BufferUsage aBufferUsage = BufferUsage.WriteOnly)
            => aItems.ToVertexPosition().ToVertexBuffer(aGraphicDevice, aBufferUsage);

        internal static void DrawLineList(this VertexBuffer aVertexBuffer, GraphicsDevice aGraphicsDevice)
        {
            aGraphicsDevice.SetVertexBuffer(aVertexBuffer);
            var aCount = aVertexBuffer.VertexCount / 2;
            for(var aIdx = 0; aIdx < aCount; ++aIdx)
            { 
                aGraphicsDevice.DrawPrimitives(PrimitiveType.LineList, aIdx * 2, 1);
            }
        }


        internal static bool IsKeyDownExclusive(this KeyboardState aKeyboardState, Keys aKeyDown, params Keys[] aNotDowns)
        {
            if (aKeyboardState.IsKeyDown(aKeyDown))
            {
                foreach (var aNotDown in aNotDowns)
                    if (aKeyboardState.IsKeyDown(aNotDown))
                        return false;
                return true;
            }
            return false;
        }
        internal static Color SetAlpha(this Color aColor, float aAlpha)
            => new Color(aColor, aAlpha);
    }

    internal static class CMonoWorldExtensions
    {
        internal static CCoordinates<double> GetGameCoordinates(this Vector3 aVector)
            => new CCoordinates<double>(aVector.X, aVector.Y, aVector.Z);
    }

    internal sealed class CBumperSprite
    :
       CSprite<CBumperSpriteData>
    {
        internal CBumperSprite(CBase aParent, CMonoFacade aMonoFacade, CBumperSpriteData aBumperSpriteData) : base(aParent, aMonoFacade, aBumperSpriteData)
        {
            this.Bumper = aBumperSpriteData;

            var aGame = aMonoFacade.Game;

            var aCenter2 = aBumperSpriteData.Coordinates2;
            var aRadius = aBumperSpriteData.Radius;
            var a1X = aCenter2[0];
            var a1Y = aCenter2[1] - aRadius;
            var a1Z = aCenter2[2];
            var a2X = aCenter2[0] + aRadius;
            var a2Y = aCenter2[1] + aRadius;
            var a2Z = aCenter2[2];
            var a3X = aCenter2[0] - aRadius;
            var a3Y = aCenter2[1] + aRadius;
            var a3Z = aCenter2[2];

            var aVertices = new VertexPositionColor[3];
            aVertices[0] = new VertexPositionColor(new Vector3((float)a1X, (float)a1Y, (float)a1Z), Color.Red);
            aVertices[1] = new VertexPositionColor(new Vector3((float)a2X, (float)a2Y, (float)a2Z), Color.Green);
            aVertices[2] = new VertexPositionColor(new Vector3((float)a3X, (float)a3Y, (float)a3Z), Color.Blue);

            //aVertices[0] = new VertexPositionColor(new Vector3(0, 20, 0), Color.Red);
            //aVertices[1] = new VertexPositionColor(new Vector3(-20, -20, 0), Color.Green);
            //aVertices[2] = new VertexPositionColor(new Vector3(20, -20, 0), Color.Blue);

            var aVertexBuffer = new VertexBuffer(aMonoFacade.Game.GraphicsDevice, typeof(VertexPositionColor), 3, BufferUsage.WriteOnly);
            aVertexBuffer.SetData<VertexPositionColor>(aVertices);
            this.VertexBuffer = aVertexBuffer;

        }

        public override T Throw<T>(Exception aException)
              => aException.Throw<T>();

        internal readonly CBumperSpriteData Bumper;
        internal readonly VertexBuffer VertexBuffer;

        internal override void Update(BitArray aChanged)
        {

        }
        internal override void DrawPrimitives()
        {
            base.DrawPrimitives();
            GraphicsDevice.SetVertexBuffer(this.VertexBuffer);
            this.GraphicsDevice.DrawPrimitives(PrimitiveType.TriangleList, 0, 3);
        }

    }

    internal sealed class CMonoFacade : CFacade
    {
        internal CMonoFacade(CGame aGame)
        {
            this.Game = aGame;
        }
        internal CRootBase Base;

        internal readonly CGame Game;
        public override ISprite<T> NewSprite<T>(T aData)
        {
            if (typeof(T) == typeof(CBumperSpriteData))
            {
                return (ISprite<T>)(object)new CBumperSprite(this.Base, this, (CBumperSpriteData)(object)aData);
            }
            else if (typeof(T) == typeof(CQuadrantSpriteData))
            {
                return (ISprite<T>)(object)new CQuadrantSprite(this.Base, this, (CQuadrantSpriteData)(object)aData);
            }
            else if(typeof(T) == typeof(CBeyoundSpaceSpriteData))
            {
                return default;
            }
            else
            {
                throw new NotImplementedException();
            }
        }

    }

    internal struct CAvatar
    {
        internal CAvatar(Vector3 aCameraPos, Vector3 aCameraTarget, Vector3 aUpVector)
        {
            this.CamPos = aCameraPos;
            this.CamTarget = aCameraTarget;
            this.UpVector = aUpVector;
            this.MoveVector = aCameraPos - aCameraTarget;
            this.ViewMatrix = Matrix.CreateLookAt(this.CamPos, this.CamTarget, this.UpVector);
        }

        internal static CAvatar Default
            => new CAvatar(Vector3.Zero, new Vector3(0, 0, MoveVectorLength), Vector3.Up);
        internal readonly Vector3 CamPos;
        internal readonly Vector3 CamTarget;
        internal readonly Vector3 UpVector;
        internal readonly Vector3 MoveVector;

        internal const float MoveVectorLength = 1f;
        internal readonly Matrix ViewMatrix;
        internal CAvatar LookUpDown( float aRadians)
            => new CAvatar(this.CamPos, this.CamTarget.RotateX(this.CamPos, aRadians), this.UpVector);
        public CAvatar LookLeftRight(float aRadians)
             => new CAvatar(this.CamPos, this.CamTarget.RotateY(this.CamPos,aRadians), this.UpVector);
        internal CAvatar MoveToOffset(Vector3 aMoveVector)
            => new CAvatar(this.CamPos + aMoveVector, this.CamTarget + aMoveVector, this.UpVector);

        internal CAvatar MoveAlongViewAngle(float aDistance)
        {
            if (aDistance != 0f)
            {
                var aMoveVector = this.MoveVector;
                var aLonger = aMoveVector.MakeLongerDelta(aDistance);
                var aNewCameraPosition = this.CamPos + aLonger;
                var aNewCameraTarget = this.CamTarget + aLonger;
                var aAvatar = new CAvatar(aNewCameraPosition, aNewCameraTarget, this.UpVector);
                return aAvatar;
            }
            else
            {
                return this;
            }
        }
        #region SErialize
        internal void Write(MemoryStream aMemoryStream)
        {
            var aStreamWriter = new BinaryWriter(aMemoryStream);
            aStreamWriter.Write((double)this.CamPos.X);
            aStreamWriter.Write((double)this.CamPos.Y);
            aStreamWriter.Write((double)this.CamPos.Z);
            aStreamWriter.Write((double)this.CamTarget.X);
            aStreamWriter.Write((double)this.CamTarget.Y);
            aStreamWriter.Write((double)this.CamTarget.Z);
            aStreamWriter.Write((double)this.UpVector.X);
            aStreamWriter.Write((double)this.UpVector.Y);
            aStreamWriter.Write((double)this.UpVector.Z);
        }

        internal static CAvatar Read(MemoryStream aMemoryStream)
        {
            var aStreamReader = new BinaryReader(aMemoryStream);
            var aPx = (float)aStreamReader.ReadDouble();
            var aPy = (float)aStreamReader.ReadDouble();
            var aPz = (float)aStreamReader.ReadDouble();
            var aTx = (float)aStreamReader.ReadDouble();
            var aTy = (float)aStreamReader.ReadDouble();
            var aTz = (float)aStreamReader.ReadDouble();
            var aUx = (float)aStreamReader.ReadDouble();
            var aUy = (float)aStreamReader.ReadDouble();
            var aUz = (float)aStreamReader.ReadDouble();
            var aP = new Vector3(aPx, aPy, aPz);
            var aT = new Vector3(aTx, aTy, aTz);
            var aU = new Vector3(aUx, aUy, aUz);
            var aA = new CAvatar(aP, aT, aU);
            return aA;
        }
        private static FileInfo FileInfo => new FileInfo(Path.Combine(new FileInfo(typeof(CAvatar).Assembly.Location).Directory.FullName, "Avatar.bin"));

        internal void Save()
        {
            var aMemoryStream = new MemoryStream();
            this.Write(aMemoryStream);
            aMemoryStream.Seek(0, SeekOrigin.Begin);
            File.WriteAllBytes(CAvatar.FileInfo.FullName, aMemoryStream.ToArray());
        }
        internal static CAvatar Load()
        {
            var aFileInfo = FileInfo;
            if(aFileInfo.Exists)
            {
                try
                {
                    var aMemoryStream = new MemoryStream(File.ReadAllBytes(aFileInfo.FullName));
                    var aAvatar = Read(aMemoryStream);
                    return aAvatar;
                }
                catch(Exception)
                {
                    return CAvatar.Default;
                }
            }
            return CAvatar.Default;
        }
        #endregion
        internal CCoordinates<double> WorldPos => this.CamPos.GetGameCoordinates();
    }

    internal struct CGameAvatar
    {
        internal CGameAvatar(CGame aGame)
        {
            this.Game = aGame;
        }
        internal readonly CGame Game;
        internal  CWorld World => this.Game.World;
        internal CAvatar Avatar => this.Game.Avatar;
        internal bool GetCubeCoordinatesIsDefined()
            => true; //this.World.GetCubeCoordinatesIsDefined(this.Avatar.WorldPos);
        internal CCoordinates<Int64> GetCubeCoordinates()
            => this.World.GetCubePos(this.Avatar.WorldPos);

    }
    internal sealed class CGame : Game
    {
        internal CGame()
        {
            this.GraphicsDeviceManager = new GraphicsDeviceManager(this);

            this.Content.RootDirectory = "Content\\bin";

            this.MonoFacade = new CMonoFacade(this);
        }

        protected override void EndRun()
        {
            base.EndRun();
            this.Avatar.Save();
        }

        internal readonly CMonoFacade MonoFacade;
        internal CWorld World => this.MonoFacade.World;
        private readonly GraphicsDeviceManager GraphicsDeviceManager;
        private SpriteBatch SpriteBatch;
        private Texture2D BallTexture;

        protected override void LoadContent()
        {

            this.Avatar = CAvatar.Load();
            this.SpriteBatch = new SpriteBatch(this.GraphicsDevice);
           // this.BallTexture = this.Content.Load<Texture2D>("Ball");

            //this.Content.Load<Texture>
            base.LoadContent();
        }

        protected override void Initialize()
        {
            this.Init3d();

            this.MonoFacade.Load();

            base.Initialize();
        }

        private bool SetMousePosition;

        protected override void Draw(GameTime gameTime)
        {
            base.Draw(gameTime);


            if(this.SetMousePosition)
            {
                //Mouse.SetPosition(this.GraphicsDevice.Viewport.Width / 2, this.GraphicsDevice.Viewport.Height / 2);
                this.SetMousePosition = false;  
            }
            //this.SpriteBatch.Begin();
            //this.SpriteBatch.Draw(this.BallTexture, new Vector2(0, 0), Color.White);
            //this.SpriteBatch.End();

            this.Draw3d();
        }

        private void UpdateInput(GameTime aGameTime)
        {
            var aEnableMouseMove = false;

            var aKeyboardState = Keyboard.GetState();
            var aAvatar = this.Avatar;
            bool aChanged = false;

            var aMouseState = Mouse.GetState();
            var aMouseDx = 0f;
            var aMouseDy = 0f;
            if (aEnableMouseMove)
            {
                var aMousePosition = aMouseState.Position;
                if (this.MousePosition.HasValue)
                {
                    var aDelta = aMousePosition - this.MousePosition.Value;
                    aMouseDx = aDelta.X;
                    aMouseDy = aDelta.Y;
                    this.SetMousePosition = true;
                }
                else
                {
                    //  Mouse.SetPosition(this.GraphicsDevice.Viewport.Width / 2, this.GraphicsDevice.Viewport.Height / 2);

                }
                this.MousePosition = aMousePosition;

            }
            var aMouseThroodle = 0f;
            if (aMouseState.RightButton == ButtonState.Pressed)
            {
                aMouseThroodle = -1.0f;
            }


            {
                var aRotX = aMouseDx * 0.5f;
                if (aKeyboardState.IsKeyDown(Keys.Right))
                    aRotX += 1.0f;
                if (aKeyboardState.IsKeyDown(Keys.Left))
                    aRotX -= 1.0f;

                if (aRotX != 0.0f)
                {
                    aAvatar = aAvatar.LookLeftRight(MathHelper.ToRadians((float)(aRotX * this.CamSpeedRy * aGameTime.ElapsedGameTime.TotalSeconds)));
                    aChanged = true;
                }
            }

            {
                var aRotY = aMouseDy * 0.5f;
                if (aKeyboardState.IsKeyDown(Keys.Down))
                    aRotY += 1.0f;
                if (aKeyboardState.IsKeyDown(Keys.Up))
                    aRotY -= 1.0f;
                if (aRotY != 0f)
                {
                    aAvatar = aAvatar.LookUpDown(MathHelper.ToRadians((float)(aRotY * this.CamSpeedRx * aGameTime.ElapsedGameTime.TotalSeconds)));
                    aChanged = true;
                }
            }

            var aThroodle = aMouseThroodle;
            if (aKeyboardState.IsKeyDown(Keys.NumPad0))
                aThroodle += 1.0f;
            if (aKeyboardState.IsKeyDown(Keys.NumPad5))
                aThroodle -= 1.0f;
            if (aThroodle != 0f)
            {
                aAvatar = aAvatar.MoveAlongViewAngle((float)(aThroodle * this.CamSpeedThroodle * aGameTime.ElapsedGameTime.TotalSeconds));
                aChanged = true;
            }

            var aDx = 0.0f;
            if (aKeyboardState.IsKeyDown(Keys.NumPad4))
                aDx += 1.0f;
            if (aKeyboardState.IsKeyDown(Keys.NumPad6))
                aDx -= 1.0f;
            if (aDx != 0)
            {
                aAvatar = aAvatar.MoveToOffset(new Vector3((float)(aDx * this.CamSpeedX * aGameTime.ElapsedGameTime.TotalSeconds), 0, 0));
                aChanged = true;
            }


            var aDy = 0.0f;
            if (aKeyboardState.IsKeyDown(Keys.NumPad8))
                aDy += 1.0f;
            if (aKeyboardState.IsKeyDown(Keys.NumPad2))
                aDy -= 1.0f;
            if (aDy != 0)
            {
                aAvatar = aAvatar.MoveToOffset(new Vector3(0, (float)(aDy * this.CamSpeedY * aGameTime.ElapsedGameTime.TotalSeconds), 0));
                aChanged = true;
            }





            if (aChanged)
            {
                this.Avatar = aAvatar;
            }
        }
        private void UpdateWorld(GameTime aGameTime)
        {
            var aGameAvatar = this.GameAvatar;
            var aCubeCoordinatesIsDefined = aGameAvatar.GetCubeCoordinatesIsDefined();
            if(aCubeCoordinatesIsDefined)
            {
                this.MonoFacade.SetCubeCoordinates(aGameAvatar.GetCubeCoordinates());
            }
        }
        protected override void Update(GameTime aGameTime)
        {
            this.UpdateInput(aGameTime);
            this.UpdateWorld(aGameTime);


            base.Update(aGameTime);
        }
        private Point? MousePosition;
        #region 3d
        private void InitRasterizerState()
        {
            var aRasterizerState = new RasterizerState();
            aRasterizerState.CullMode = CullMode.None;
            this.GraphicsDevice.RasterizerState = aRasterizerState;
        }
        #region Avatar
        private CAvatar AvatarM = CAvatar.Default;
        internal CAvatar Avatar
        {
            get => this.AvatarM; 
            set 
            {
                this.AvatarM = value;
                if (this.AvatarChanged is object)
                    this.AvatarChanged();
            }
        }
        internal event Action AvatarChanged;
        internal CGameAvatar GameAvatar => new CGameAvatar(this);
        #endregion

        #region Camera
        private Vector3 CameraTarget => this.Avatar.CamTarget;
        private Vector3 CameraPosition => this.Avatar.CamPos;


        private float CamSpeedRatio => (float)(this.WorldScale * this.MonoFacade.World.TileSize2);
        private float CamSpeedY => this.CamSpeedRatio;
        private float CamSpeedX => this.CamSpeedRatio;
        private float CamSpeedRy => 90f;
        private float CamSpeedRx => 90f;

        private float CamSpeedThroodle => this.CamSpeedRatio;

        #endregion
        #region WorldMatrix
        private readonly Vector3 WorldPosition = new Vector3(-0, -0, 0f);
        internal Matrix WorldMatrix { get; private set; }
        private readonly float WorldScale = 1f;
        private void InitWorldMatrix()
        {
            var aPosition = this.WorldPosition;
            var aWorldMatrix1 = Matrix.CreateWorld(aPosition, Vector3.Forward, Vector3.Up);
            var aScaleMatrix = Matrix.CreateScale(this.WorldScale);
            var aWorldMatrix2 = aWorldMatrix1 * aScaleMatrix;
            this.WorldMatrix = aWorldMatrix2;
        }

        #endregion
        #region ViewMatrix
        internal Matrix ViewMatrix => this.Avatar.ViewMatrix;
        //internal Matrix ViewMatrix => new CAvatar(new Vector3(-1500, 0, -6700), new Vector3(-1500, 0, 6750), Vector3.Up).ViewMatrix;
        #endregion
        #region ProjectionMatrix
        private Matrix ProjectionMatrixM;
        internal Matrix ProjectionMatrix
        {
            get => this.ProjectionMatrixM;
            set
            {
                this.ProjectionMatrixM = value;
                if (this.ProjectionMatrixChanged is object)
                    this.ProjectionMatrixChanged();
            }
        }
        internal event Action ProjectionMatrixChanged;
        private void InitProjectionMatrix()
        {
            this.UpdateProjectionMatrix();
        }
        private void UpdateProjectionMatrix()
        {
            this.ProjectionMatrix = Matrix.CreatePerspectiveFieldOfView
            (
                MathHelper.ToRadians(45f), 
                GraphicsDevice.DisplayMode.AspectRatio, 
                0.0001f, 
                10000f 
            );
        }
        #endregion
        #region BasicEffect
        internal BasicEffect BasicEffect { get; private set; }
        private void InitBasicEffect()
        {
            this.BasicEffect = new BasicEffect(GraphicsDevice);
            this.UpdateBasicEffect();
            this.AvatarChanged += this.UpdateBasicEffect;
        }
        private void UpdateBasicEffect()
        {
            this.BasicEffect.Alpha = 1f;
            this.BasicEffect.VertexColorEnabled = true;
            this.BasicEffect.View = this.ViewMatrix;
            this.BasicEffect.World = this.WorldMatrix;
            this.BasicEffect.Projection = this.ProjectionMatrix;
        }
        #endregion
        #region Triangle
        VertexPositionColor[] TriangleVertices;
        VertexBuffer VertexBuffer;
        private void DrawTriangle()
        {
            var aDrawTriangle = true;
            if (aDrawTriangle)
            {
                GraphicsDevice.SetVertexBuffer(VertexBuffer);
                foreach (var aEffectPass in this.BasicEffect.CurrentTechnique.Passes)
                {
                    aEffectPass.Apply();
                    GraphicsDevice.DrawPrimitives(PrimitiveType.
                                                  TriangleList, 0, 3);
                }
            }
        }
        private void InitTriangle()
        {
            this.TriangleVertices = new VertexPositionColor[3];
            var d = 30000;
            var e = 0;
            this.TriangleVertices[0] = new VertexPositionColor(new Vector3(d, 0, e), Color.Red);
            this.TriangleVertices[1] = new VertexPositionColor(new Vector3(0, 0, e), Color.Yellow);
            this.TriangleVertices[2] = new VertexPositionColor(new Vector3(d/2.0f, -d, e), Color.Blue);

            //this.TriangleVertices[0] = new VertexPositionColor(new Vector3(0, d, e), Color.Red);
            //TriangleVertices[1] = new VertexPositionColor(new Vector3(-d, -d, e), Color.Green);
            //TriangleVertices[2] = new VertexPositionColor(new Vector3(d, -d, e), Color.Blue);
            VertexBuffer = new VertexBuffer(GraphicsDevice, typeof(VertexPositionColor), 3, BufferUsage.WriteOnly);
            VertexBuffer.SetData<VertexPositionColor>(TriangleVertices);
        }
        #endregion
        #region Coordinates
        private VertexBuffer CoordinatesVertexBufferM;
        private VertexBuffer CoordinatesVertexBuffer => CLazyLoad.Get(ref this.CoordinatesVertexBufferM, this.NewCoordinatesVertexBuffer);
        private VertexBuffer NewCoordinatesVertexBuffer()
        {
            var aMaxCoord = 1;
            var aOrigin = new Vector3(0, 0, 0);
            var aMaxX = new Vector3(aMaxCoord, 0, 0);
            var aMaxY = new Vector3(0, aMaxCoord, 0);
            var aMaxZ = new Vector3(0, 0, aMaxCoord);
            var aLines = new VertexPositionColor[]
            {
               new VertexPositionColor(aOrigin, Color.Red),
               new VertexPositionColor(aMaxX, Color.Red),
                new VertexPositionColor(aOrigin, Color.Green),
                new VertexPositionColor(aMaxY, Color.Green),
                 new VertexPositionColor(aOrigin, Color.Blue),
                 new VertexPositionColor(aMaxZ, Color.Blue),
            };
            var aVertexBuffer = aLines.ToVertexBuffer(this.GraphicsDevice);
            return aVertexBuffer;
        }
        private void DrawCoordinates()
        {
            var aDrawCoordinates = true;
            if (aDrawCoordinates)
            {
                foreach (var aEffectPass in this.BasicEffect.CurrentTechnique.Passes)
                {
                    aEffectPass.Apply();
                    this.CoordinatesVertexBuffer.DrawLineList(this.GraphicsDevice);
                }
            }
        }
        #endregion

        private void Init3d()
        {
            this.InitRasterizerState();
            this.InitWorldMatrix();
            this.InitProjectionMatrix();
            this.InitBasicEffect();
            this.InitTriangle();
        }

        private void Draw3d()
        {
            GraphicsDevice.Clear(Color.Black);

            //this.DrawTriangle();


            this.MonoFacade.Draw();



            this.DrawCoordinates();

        }

        #endregion

    }
}
